alert("Bem Vindo!");
function exibir() {
  var nome = document.getElementById("txtnome").value;
  var sobrenome = document.getElementById("txtsobre").value;
  alert("Nome: " + nome + " " + sobrenome);
}
//window.alert("Funcionou!"); // pop-up página

/* var valor = parseInt("funcionou", 10);
   alert(`Valor ${valor}`); */
